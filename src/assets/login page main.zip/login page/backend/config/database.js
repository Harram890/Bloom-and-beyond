const { Sequelize } = require("sequelize");
require("dotenv").config();

const createDatabase = async () => {
  const sequelize = new Sequelize("", process.env.DB_USER, process.env.DB_PASSWORD, {
    host: process.env.DB_HOST,
    dialect: process.env.DB_DIALECT,
    logging: false,
  });

  try {
    await sequelize.query(
      `CREATE DATABASE IF NOT EXISTS \`${process.env.DB_NAME}\``
    );

    console.log("Database checked/created successfully");

    await sequelize.close();
  } catch (error) {
    console.error("Database creation failed:", error);
    process.exit(1);
  }
};

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    dialect: process.env.DB_DIALECT,
    logging: false,
  }
);

module.exports = {
  sequelize,
  createDatabase,
};