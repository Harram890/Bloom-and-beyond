const sequelize = require("../config/database").sequelize;
const User = require("./User");

const db = {
  sequelize,
  User,
};

module.exports = db;