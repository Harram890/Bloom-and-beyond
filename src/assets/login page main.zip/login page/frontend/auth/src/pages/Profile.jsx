import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../service/api";

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("token");

    if (!token) {
      navigate("/login", { replace: true });
      return;
    }

    api
      .get("/api/auth/profile", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        setUser(response.data.user);
      })
      .catch((err) => {
        if (err.response?.status === 401 ||
            err.response?.status === 403) {
          localStorage.removeItem("token");
          navigate("/login", { replace: true });
        } else {
          setError("Profile load nahi ho saka.");
        }
      });
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login", { replace: true });
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-100 px-4">
      <div className="w-full max-w-lg rounded-2xl bg-white p-8 shadow-xl">
        <h1 className="text-2xl font-bold text-slate-900">
          Your Profile
        </h1>

        {error && (
          <p className="mt-4 text-red-600">{error}</p>
        )}

        {!user && !error && (
          <p className="mt-5 text-slate-500">
            Loading profile...
          </p>
        )}

        {user && (
          <div className="mt-6 space-y-3">
            <p>
              <span className="font-semibold">Name:</span>{" "}
              {user.name}
            </p>

            <p>
              <span className="font-semibold">Email:</span>{" "}
              {user.email}
            </p>
          </div>
        )}

        <button
          onClick={handleLogout}
          className="mt-8 rounded-lg bg-red-600 px-5 py-3 font-semibold text-white hover:bg-red-700"
        >
          Logout
        </button>
      </div>
    </div>
  );
}